Codec: Realtek ALC298
Address: 0
AFG Function Id: 0x1 (unsol 1)
Vendor Id: 0x10ec0298
Subsystem Id: 0x1a586755
Revision Id: 0x100103


You must change the Layout to 13  in the DSDT patch HDEF.
Kext Patched by Insanelydeepak 

Notes for installation :
1. use latest version of CodecCommander + SSDT298 

2.if you have Kabylake system then you must use FakePCIID.kexts + FakePCIID_Intel_HDMI_Audio.kext







